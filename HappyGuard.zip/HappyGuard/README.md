# HappyGuard

Anticheat voor Paper 1.21.11 (Java 21).

## Bouwen
```
mvn clean package
```
De jar staat daarna in `target/HappyGuard-1.0.0.jar`. Zet die in `plugins/`.

## Wat doet het
- **Anti-ESP / anti-freecam**: entities zonder line-of-sight worden voor de client verborgen (`hideEntity`).
- **Xray-detectie**: statistisch, telt "blind" gevonden ores t.o.v. gesloopte stenen. Standaard alleen alerts, geen straf.
- Staff-alerts (`happyguard.alerts`), `/hg alerts|reload|vl|reset`, VL met decay.

## Belangrijk: zet ook Paper's anti-xray aan
Dit is de sterkste bescherming, want de ores worden dan nooit naar de client gestuurd.
In `config/paper-world-defaults.yml`:
```yaml
anticheat:
  anti-xray:
    enabled: true
    engine-mode: 2
    hidden-blocks: [copper_ore, deepslate_copper_ore, gold_ore, deepslate_gold_ore, iron_ore,
      deepslate_iron_ore, coal_ore, deepslate_coal_ore, lapis_ore, deepslate_lapis_ore,
      mossy_cobblestone, obsidian, chest, diamond_ore, deepslate_diamond_ore, redstone_ore,
      deepslate_redstone_ore, clay, emerald_ore, deepslate_emerald_ore, ender_chest]
    replacement-blocks: [stone, oak_planks, deepslate]
```
(Nether: zet `ancient_debris` in de hidden-blocks van de nether-instelling.)

## Permissies
- `happyguard.admin` - /hg
- `happyguard.alerts` - alerts ontvangen
- `happyguard.bypass` - niet gecontroleerd

## Let op
Freecam is puur client-side en niet direct te detecteren; anti-ESP zorgt dat het niets oplevert.
Folia wordt niet ondersteund.

## Bouwen zonder Java/Maven (GitHub)
1. Maak een gratis repository op github.com en upload de inhoud van deze map (inclusief `.github`).
2. Ga naar het tabblad **Actions**, open de laatste "Build"-run (of start hem met "Run workflow").
3. Download onderaan de **HappyGuard** artifact. Pak die zip uit: daarin zit de `.jar`.
