package nl.happysmp.guard;

import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.ArrayDeque;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Statistische Xray-check.
 *
 * Een "blind reveal" is wanneer een speler een steenblok sloopt waarvan een buur
 * een ore is die tot dat moment volledig omsloten was (niet zichtbaar vanuit een grot).
 * Sloopt de speler die ore daarna, dan telt dat als "blind ore".
 * Een Xray-speler heeft veel meer blind ores per gesloopte steen dan een normale speler.
 */
public class XrayCheck implements Listener {

    private static final BlockFace[] FACES = {
            BlockFace.UP, BlockFace.DOWN, BlockFace.NORTH,
            BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST
    };
    private static final int MAX_REVEALED = 64;

    private final HappyGuard plugin;
    private final Map<UUID, Data> data = new HashMap<>();
    private final Set<Material> ores = EnumSet.noneOf(Material.class);

    public XrayCheck(HappyGuard plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        ores.clear();
        for (String name : plugin.getConfig().getStringList("xray.ores")) {
            Material m = Material.matchMaterial(name);
            if (m != null) {
                ores.add(m);
            } else {
                plugin.getLogger().warning("Onbekende ore in config: " + name);
            }
        }
        data.clear();
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (!plugin.getConfig().getBoolean("xray.enabled", true)) {
            return;
        }
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR
                || player.hasPermission("happyguard.bypass")) {
            return;
        }

        Block block = event.getBlock();
        Material type = block.getType();
        long now = System.currentTimeMillis();
        long window = plugin.getConfig().getLong("xray.window-seconds", 600) * 1000L;

        Data d = data.computeIfAbsent(player.getUniqueId(), k -> new Data());
        d.prune(now, window);

        if (d.worldId != null && !d.worldId.equals(block.getWorld().getUID())) {
            d.revealed.clear();
        }
        d.worldId = block.getWorld().getUID();

        if (isStone(type)) {
            d.stoneTimes.add(now);
            // Kijk of dit blok een verborgen ore blootlegt
            for (BlockFace face : FACES) {
                Block neighbour = block.getRelative(face);
                if (ores.contains(neighbour.getType()) && wasHidden(neighbour, block)) {
                    d.reveal(neighbour.getBlockKey());
                }
            }
            return;
        }

        if (ores.contains(type)) {
            if (d.revealed.remove(block.getBlockKey())) {
                d.blindTimes.add(now);
                evaluate(player, d);
            }
        }
    }

    private void evaluate(Player player, Data d) {
        int stone = d.stoneTimes.size();
        int blind = d.blindTimes.size();
        int minStone = plugin.getConfig().getInt("xray.min-stone", 40);
        int minBlind = plugin.getConfig().getInt("xray.min-blind-ores", 4);
        double maxRatio = plugin.getConfig().getDouble("xray.max-ratio", 0.06);

        if (stone < minStone || blind < minBlind) {
            return;
        }
        double ratio = (double) blind / stone;
        if (ratio <= maxRatio) {
            return;
        }
        String info = String.format("blind=%d stone=%d ratio=%.1f%%", blind, stone, ratio * 100.0);
        plugin.violations().flag(player, "Xray", info,
                plugin.getConfig().getDouble("xray.vl-per-flag", 2.0),
                plugin.getConfig().getDouble("xray.alert-vl", 2.0),
                plugin.getConfig().getDouble("xray.punish-vl", 0),
                plugin.getConfig().getStringList("xray.punish-commands"));
    }

    private boolean isStone(Material m) {
        return Tag.BASE_STONE_OVERWORLD.isTagged(m) || Tag.BASE_STONE_NETHER.isTagged(m);
    }

    /**
     * Was de ore volledig omsloten voordat 'broken' werd gesloopt?
     * Alle andere buren moeten dan solide (niet lucht/vloeistof/passeerbaar) zijn.
     */
    private boolean wasHidden(Block ore, Block broken) {
        for (BlockFace face : FACES) {
            Block n = ore.getRelative(face);
            if (n.equals(broken)) {
                continue;
            }
            Material t = n.getType();
            if (t.isAir() || n.isLiquid() || n.isPassable() || !t.isOccluding()) {
                return false;
            }
        }
        return true;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        data.remove(event.getPlayer().getUniqueId());
    }

    private static final class Data {
        final ArrayDeque<Long> stoneTimes = new ArrayDeque<>();
        final ArrayDeque<Long> blindTimes = new ArrayDeque<>();
        final Set<Long> revealed = new LinkedHashSet<>();
        UUID worldId;

        void prune(long now, long window) {
            while (!stoneTimes.isEmpty() && now - stoneTimes.peekFirst() > window) {
                stoneTimes.pollFirst();
            }
            while (!blindTimes.isEmpty() && now - blindTimes.peekFirst() > window) {
                blindTimes.pollFirst();
            }
        }

        void reveal(long key) {
            revealed.add(key);
            if (revealed.size() > MAX_REVEALED) {
                java.util.Iterator<Long> it = revealed.iterator();
                it.next();
                it.remove();
            }
        }
    }
}
