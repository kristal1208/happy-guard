package nl.happysmp.guard;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ViolationManager {

    private final HappyGuard plugin;
    private final Map<UUID, Map<String, Double>> vl = new ConcurrentHashMap<>();
    private final Set<UUID> alertsOff = new HashSet<>();

    public ViolationManager(HappyGuard plugin) {
        this.plugin = plugin;
    }

    /**
     * Voeg violation level toe, stuur alert en voer eventueel straf uit.
     */
    public void flag(Player player, String check, String info, double amount,
                     double alertVl, double punishVl, java.util.List<String> punishCommands) {
        Map<String, Double> map = vl.computeIfAbsent(player.getUniqueId(), k -> new ConcurrentHashMap<>());
        double total = map.merge(check, amount, Double::sum);

        if (total >= alertVl) {
            String message = plugin.prefix() + plugin.color(plugin.getConfig()
                    .getString("messages.alert", "&c%player% &7flagde &f%check% &8(&f%info%&8) &7VL: &c%vl%")
                    .replace("%player%", player.getName())
                    .replace("%check%", check)
                    .replace("%info%", info)
                    .replace("%vl%", String.format("%.1f", total)));
            for (Player staff : Bukkit.getOnlinePlayers()) {
                if (staff.hasPermission("happyguard.alerts") && !alertsOff.contains(staff.getUniqueId())) {
                    staff.sendMessage(message);
                }
            }
            plugin.getLogger().info("[" + check + "] " + player.getName() + " " + info + " VL=" + String.format("%.1f", total));
        }

        if (punishVl > 0 && total >= punishVl && punishCommands != null) {
            map.put(check, 0.0);
            for (String command : punishCommands) {
                String c = command.replace("%player%", player.getName());
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), c);
            }
        }
    }

    public double get(UUID id, String check) {
        Map<String, Double> map = vl.get(id);
        return map == null ? 0.0 : map.getOrDefault(check, 0.0);
    }

    public Map<String, Double> getAll(UUID id) {
        return vl.getOrDefault(id, Map.of());
    }

    public void reset(UUID id) {
        vl.remove(id);
    }

    public void decay() {
        double amount = plugin.getConfig().getDouble("violations.decay-per-minute", 1.0);
        for (Map<String, Double> map : vl.values()) {
            map.replaceAll((k, v) -> Math.max(0.0, v - amount));
        }
        vl.values().removeIf(m -> m.values().stream().allMatch(v -> v <= 0.0));
    }

    public boolean toggleAlerts(UUID id) {
        if (alertsOff.remove(id)) {
            return true;
        }
        alertsOff.add(id);
        return false;
    }
}
