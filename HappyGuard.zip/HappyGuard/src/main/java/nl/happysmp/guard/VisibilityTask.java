package nl.happysmp.guard;

import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Anti-ESP / anti-freecam.
 *
 * De server stuurt entities die de speler niet kan zien helemaal niet naar de client
 * (hideEntity). Een ESP-hack kan daardoor niets door muren tekenen, en een freecam-hack
 * ziet alleen entities die vanuit het echte oog van de speler zichtbaar zijn.
 */
public class VisibilityTask implements Runnable, Listener {

    private final HappyGuard plugin;
    // observer -> entities die wij voor hem verborgen hebben
    private final Map<UUID, Set<UUID>> hidden = new HashMap<>();

    public VisibilityTask(HappyGuard plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        double minDist = plugin.getConfig().getDouble("anti-esp.min-hide-distance", 6.0);
        double maxDist = plugin.getConfig().getDouble("anti-esp.max-distance", 96.0);
        boolean hideMobs = plugin.getConfig().getBoolean("anti-esp.hide-mobs", false);
        boolean ignoreSpec = plugin.getConfig().getBoolean("anti-esp.ignore-spectators", true);

        for (Player observer : plugin.getServer().getOnlinePlayers()) {
            if (observer.hasPermission("happyguard.bypass") || observer.getGameMode() == GameMode.SPECTATOR) {
                showAllFor(observer);
                continue;
            }
            Set<UUID> hiddenForObserver = hidden.computeIfAbsent(observer.getUniqueId(), k -> new HashSet<>());
            World world = observer.getWorld();
            Location eye = observer.getEyeLocation();

            for (Entity target : observer.getNearbyEntities(maxDist, maxDist, maxDist)) {
                if (!(target instanceof Player) && !(hideMobs && target instanceof LivingEntity)) {
                    continue;
                }
                if (target instanceof Player tp && ignoreSpec && tp.getGameMode() == GameMode.SPECTATOR) {
                    continue;
                }
                if (target.isInsideVehicle() && target.getVehicle() == observer) {
                    continue;
                }

                boolean shouldHide = false;
                if (target.getWorld().equals(world)) {
                    double distSq = target.getLocation().distanceSquared(eye);
                    if (distSq > minDist * minDist) {
                        shouldHide = !isVisible(world, eye, target);
                    }
                }

                UUID tid = target.getUniqueId();
                if (shouldHide) {
                    if (hiddenForObserver.add(tid)) {
                        observer.hideEntity(plugin, target);
                    }
                } else if (hiddenForObserver.remove(tid)) {
                    observer.showEntity(plugin, target);
                }
            }

            // Opruimen: entities die niet meer bestaan/in de buurt zijn
            Iterator<UUID> it = hiddenForObserver.iterator();
            while (it.hasNext()) {
                UUID id = it.next();
                Entity e = plugin.getServer().getEntity(id);
                if (e == null || !e.getWorld().equals(world)) {
                    it.remove();
                    if (e != null) {
                        observer.showEntity(plugin, e);
                    }
                }
            }
        }
    }

    /**
     * Zichtbaar als vanuit het oog een rechte lijn naar minstens één punt van de
     * hitbox van het doel bestaat zonder dat een solide blok in de weg zit.
     */
    private boolean isVisible(World world, Location eye, Entity target) {
        BoundingBox box = target.getBoundingBox().expand(0.15);
        double[][] points = {
                {box.getCenterX(), box.getCenterY(), box.getCenterZ()},
                {box.getCenterX(), box.getMaxY(), box.getCenterZ()},
                {box.getCenterX(), box.getMinY(), box.getCenterZ()},
                {box.getMinX(), box.getCenterY(), box.getMinZ()},
                {box.getMaxX(), box.getCenterY(), box.getMinZ()},
                {box.getMinX(), box.getCenterY(), box.getMaxZ()},
                {box.getMaxX(), box.getCenterY(), box.getMaxZ()},
        };
        Vector origin = eye.toVector();
        for (double[] p : points) {
            Vector to = new Vector(p[0], p[1], p[2]);
            Vector dir = to.clone().subtract(origin);
            double len = dir.length();
            if (len < 0.001) {
                return true;
            }
            dir.normalize();
            if (world.rayTraceBlocks(eye, dir, len, FluidCollisionMode.NEVER, true) == null) {
                return true;
            }
        }
        return false;
    }

    private void showAllFor(Player observer) {
        Set<UUID> set = hidden.remove(observer.getUniqueId());
        if (set == null) {
            return;
        }
        for (UUID id : set) {
            Entity e = plugin.getServer().getEntity(id);
            if (e != null) {
                observer.showEntity(plugin, e);
            }
        }
    }

    public void showAll() {
        for (Player observer : plugin.getServer().getOnlinePlayers()) {
            showAllFor(observer);
        }
        hidden.clear();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player quitter = event.getPlayer();
        hidden.remove(quitter.getUniqueId());
        for (Set<UUID> set : hidden.values()) {
            set.remove(quitter.getUniqueId());
        }
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent event) {
        // Na een teleport meteen alles opnieuw laten berekenen
        showAllFor(event.getPlayer());
    }
}
