package nl.happysmp.guard;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

public final class HappyGuard extends JavaPlugin {

    private ViolationManager violations;
    private XrayCheck xrayCheck;
    private VisibilityTask visibilityTask;
    private BukkitTask visibilityBukkitTask;
    private BukkitTask decayTask;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        violations = new ViolationManager(this);
        xrayCheck = new XrayCheck(this);
        visibilityTask = new VisibilityTask(this);

        Bukkit.getPluginManager().registerEvents(xrayCheck, this);
        Bukkit.getPluginManager().registerEvents(visibilityTask, this);

        PluginCommand cmd = getCommand("happyguard");
        if (cmd != null) {
            HappyGuardCommand handler = new HappyGuardCommand(this);
            cmd.setExecutor(handler);
            cmd.setTabCompleter(handler);
        }

        startTasks();
        getLogger().info("HappyGuard ingeschakeld.");
    }

    @Override
    public void onDisable() {
        stopTasks();
        if (visibilityTask != null) {
            visibilityTask.showAll();
        }
    }

    public void reload() {
        reloadConfig();
        stopTasks();
        xrayCheck.reload();
        visibilityTask.showAll();
        startTasks();
    }

    private void startTasks() {
        if (getConfig().getBoolean("anti-esp.enabled", true)) {
            long interval = Math.max(1, getConfig().getLong("anti-esp.interval-ticks", 5));
            visibilityBukkitTask = Bukkit.getScheduler().runTaskTimer(this, visibilityTask, 40L, interval);
        }
        decayTask = Bukkit.getScheduler().runTaskTimer(this, violations::decay, 1200L, 1200L);
    }

    private void stopTasks() {
        if (visibilityBukkitTask != null) {
            visibilityBukkitTask.cancel();
            visibilityBukkitTask = null;
        }
        if (decayTask != null) {
            decayTask.cancel();
            decayTask = null;
        }
    }

    public ViolationManager violations() {
        return violations;
    }

    public String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    public String prefix() {
        return color(getConfig().getString("prefix", "&8[&cHappyGuard&8] "));
    }

    public String msg(String key) {
        return prefix() + color(getConfig().getString("messages." + key, key));
    }
}
