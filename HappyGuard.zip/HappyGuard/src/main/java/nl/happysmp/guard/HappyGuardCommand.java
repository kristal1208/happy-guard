package nl.happysmp.guard;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class HappyGuardCommand implements CommandExecutor, TabCompleter {

    private final HappyGuard plugin;

    public HappyGuardCommand(HappyGuard plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("happyguard.admin")) {
            sender.sendMessage(plugin.msg("no-permission"));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(plugin.prefix() + plugin.color("&7/hg alerts | reload | vl <speler> | reset <speler>"));
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "alerts" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("Alleen voor spelers.");
                    return true;
                }
                boolean on = plugin.violations().toggleAlerts(p.getUniqueId());
                sender.sendMessage(plugin.msg(on ? "alerts-on" : "alerts-off"));
            }
            case "reload" -> {
                plugin.reload();
                sender.sendMessage(plugin.msg("reloaded"));
            }
            case "vl" -> {
                Player target = args.length > 1 ? Bukkit.getPlayerExact(args[1]) : null;
                if (target == null) {
                    sender.sendMessage(plugin.prefix() + plugin.color("&cSpeler niet gevonden."));
                    return true;
                }
                Map<String, Double> all = plugin.violations().getAll(target.getUniqueId());
                if (all.isEmpty()) {
                    sender.sendMessage(plugin.prefix() + plugin.color("&a" + target.getName() + " heeft geen VL."));
                } else {
                    all.forEach((check, v) -> sender.sendMessage(plugin.prefix()
                            + plugin.color("&7" + target.getName() + " &f" + check + "&7: &c" + String.format("%.1f", v))));
                }
            }
            case "reset" -> {
                Player target = args.length > 1 ? Bukkit.getPlayerExact(args[1]) : null;
                if (target == null) {
                    sender.sendMessage(plugin.prefix() + plugin.color("&cSpeler niet gevonden."));
                    return true;
                }
                plugin.violations().reset(target.getUniqueId());
                sender.sendMessage(plugin.prefix() + plugin.color("&aVL van " + target.getName() + " gereset."));
            }
            default -> sender.sendMessage(plugin.prefix() + plugin.color("&7/hg alerts | reload | vl <speler> | reset <speler>"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("alerts", "reload", "vl", "reset")) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) {
                    out.add(s);
                }
            }
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("vl") || args[0].equalsIgnoreCase("reset"))) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) {
                    out.add(p.getName());
                }
            }
        }
        return out;
    }
}
